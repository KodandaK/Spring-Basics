package com.kk.beans;

import java.util.Iterator;
import java.util.List;

public class Player {
	private String playerId;
	private String playerName;
	private List<Country> country;
	
	
	public Player() {
		System.out.println("Player : zero- Param Constuctor");
	}
	
	public Player(String playerId, String playerName, List<Country> country) {
		super();
		this.playerId=playerId;
		this.playerName=playerName;
		this.country=country;
	}
	public void display() {
		
		System.out.println("Plyaer ID  : " +playerId+" Player Name     "+playerName);
		//System.out.println("Country  is   : ");
		Iterator<Country> itr=country.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
			
		}
	}
	
}
