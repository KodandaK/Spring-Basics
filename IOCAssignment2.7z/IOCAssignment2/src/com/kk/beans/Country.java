package com.kk.beans;

public class Country {
	private String countryId;
	private String countryName;
	
	public Country() {
		System.out.println("Country : Zero - Param Constuctor : ");
	}
	
	public Country(String countryId,String countryName) {
		super();
		this.countryId=countryId;
		this.countryName=countryName;
	
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Country id : " +countryId + " Country name :  " + countryName +"\n";
	}
	
}
