package com.kk.test;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.kk.beans.Player;


public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileSystemResource res=new FileSystemResource("src/com/kk/cfgs/applicationContext.xml");
		//Activate Bean Factory Container 
		XmlBeanFactory factory=new XmlBeanFactory(res);
		 
		Player p1=(Player)factory.getBean("player1");
		Player p2=(Player)factory.getBean("player2");
		Player p3=(Player)factory.getBean("player3");
		Player p4=(Player)factory.getBean("player4");
		Player p5=(Player)factory.getBean("player5");
	
		p1.display();
		p2.display();
		p3.display();
		p4.display();
		p5.display();
	}

}
