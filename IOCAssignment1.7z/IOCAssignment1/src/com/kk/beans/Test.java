package com.kk.beans;

public class Test {
	private String testId;
	private String testTitle;
	private int testMarks;
	
	public Test() {
		System.out.println("Test Zero - Param Constuctor : ");
	}
	
	public Test(String testId,String testTitle,int testMarks) {
		super();
		this.testId=testId;
		this.testTitle=testTitle;
		this.testMarks=testMarks;
		
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return testId + "  " + testTitle +"  " + testMarks;
	}
	
}
