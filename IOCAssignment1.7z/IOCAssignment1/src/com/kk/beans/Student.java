package com.kk.beans;

import java.util.Iterator;
import java.util.List;

public class Student {
	private String studentId;
	private String studentName;
	private List<Test> studentTest;
	
	
	public Student() {
		System.out.println("zero- Param Constuctor");
	}
	
	public Student(String studentId, String studentName, List<Test> studentTest) {
		super();
		this.studentId=studentId;
		this.studentName=studentName;
		this.studentTest=studentTest;
	}
	public void display() {
		
		System.out.println("Student information : " +studentId+"     "+studentName);
		System.out.println("Tests are  : ");
		Iterator<Test> itr=studentTest.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
			
		}
	}
	
}
