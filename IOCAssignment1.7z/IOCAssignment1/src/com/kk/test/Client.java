package com.kk.test;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.kk.beans.Student;


public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileSystemResource res=new FileSystemResource("src/com/kk/cfgs/applicationContext.xml");
		//Activate Bean Factory Container 
		XmlBeanFactory factory=new XmlBeanFactory(res);
		 
		Student s=(Student)factory.getBean("stu1");
		Student s2=(Student)factory.getBean("stu2");
		
		s.display();
		s2.display();
	}

}
